require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const fs         = require('fs');
const path       = require('path');
const nodemailer = require('nodemailer');
const { LowSync } = require('lowdb');
const { JSONFileSync } = require('lowdb/node');

const app  = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

/* ════════════════════════════════════════════════
   DATABASE  (lowdb — JSON file, persists on disk)
═══════════════════════════════════════════════════*/
const DB_PATH = path.join(__dirname, 'data', 'database.json');

if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

const adapter = new JSONFileSync(DB_PATH);
const db      = new LowSync(adapter, {});
db.read();

if (!db.data || !db.data.users) {
  db.data = {
    users: [
      { id:'S001', name:'Sushma M',     email:'sushma.cse.rymec99@gmail.com',   password:'student123', role:'student', branch:'Computer Science Engineering', semester:6, cgpa:8.0, attendance:90, points:1250 },
      { id:'S002', name:'Sharana',      email:'sharana.cse.rymec44@gmail.com',  password:'student123', role:'student', branch:'Computer Science Engineering', semester:4, cgpa:7.5, attendance:85, points:860  },
      { id:'S003', name:'Shashi Rekha', email:'shashirekha.cse.rymec@gmail.com',password:'student123', role:'student', branch:'Data Science',                 semester:4, cgpa:7.8, attendance:88, points:980  },
      { id:'S004', name:'Abhishek',     email:'abhishek.rymec@gmail.com',       password:'student123', role:'student', branch:'Computer Science Engineering', semester:5, cgpa:7.2, attendance:80, points:750  },
      { id:'S005', name:'Bhavana',      email:'bhavana.rymec@gmail.com',        password:'student123', role:'student', branch:'Computer Science Engineering', semester:5, cgpa:8.3, attendance:92, points:1100 },
      { id:'T001', name:'Harsha',       email:'harsha.faculty.rymec@gmail.com', password:'teacher123', role:'teacher', department:'Computer Science', subject:'Machine Learning'   },
      { id:'T002', name:'Abhinandan',   email:'abhinandan.faculty.rymec@gmail.com', password:'teacher123', role:'teacher', department:'Computer Science', subject:'Data Structures' },
      { id:'T003', name:'Hafsa',        email:'hafsa.faculty.rymec@gmail.com',  password:'teacher123', role:'teacher', department:'Data Science',      subject:'Statistics & ML'   },
    ],
    login_logs: [],
    points_db:  {},
  };
  db.write();
  console.log('✅ Database seeded with real students & teachers');
} else {
  console.log(`✅ Database loaded — ${db.data.users.length} users`);
}

/* ════════════════════════════════════════════════
   EMAIL
═══════════════════════════════════════════════════*/
const SENDER_EMAIL = process.env.SENDER_EMAIL || 'sushma.cse.rymec99@gmail.com';
const SENDER_PASS  = process.env.SENDER_PASS  || 'tzfyhfwbpajwlypo';

let transporter = null;
if (SENDER_EMAIL !== 'YOUR_GMAIL@gmail.com') {
  transporter = nodemailer.createTransport({ service:'gmail', auth:{ user:SENDER_EMAIL, pass:SENDER_PASS } });
  console.log(`✅ Email configured: ${SENDER_EMAIL}`);
} else {
  console.warn('⚠️  Email not configured. Edit .env to enable login emails.');
}

async function sendLoginEmail(user) {
  if (!transporter) return;
  const now = new Date().toLocaleString('en-IN', { timeZone:'Asia/Kolkata' });
  const isStudent = user.role === 'student';
  const html = `<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;background:#0f172a;color:#e2e8f0;border-radius:16px;overflow:hidden;">
  <div style="background:linear-gradient(135deg,#6366f1,#a78bfa);padding:28px 32px;text-align:center;">
    <div style="font-size:36px;margin-bottom:8px;">🎓</div>
    <h1 style="margin:0;color:white;font-size:22px;">EduPredict</h1>
    <p style="margin:4px 0 0;color:rgba(255,255,255,0.8);font-size:13px;">RYMEC — AI Student Intelligence Platform</p>
  </div>
  <div style="padding:28px 32px;">
    <h2 style="color:#a78bfa;font-size:16px;margin:0 0 16px;">🔐 Login Notification</h2>
    <p style="margin:0 0 20px;color:#cbd5e1;">Hi <strong style="color:white;">${user.name}</strong>, a login was detected on your account.</p>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
      <tr><td style="padding:10px 14px;background:#1e293b;border-radius:8px 8px 0 0;color:#94a3b8;width:40%;">👤 Name</td><td style="padding:10px 14px;background:#1e293b;color:white;">${user.name}</td></tr>
      <tr><td style="padding:10px 14px;background:#162032;color:#94a3b8;">📧 Email</td><td style="padding:10px 14px;background:#162032;color:white;">${user.email}</td></tr>
      <tr><td style="padding:10px 14px;background:#1e293b;color:#94a3b8;">🏷️ Role</td><td style="padding:10px 14px;background:#1e293b;color:white;">${isStudent?'🎓 Student':'👨‍🏫 Teacher'}</td></tr>
      ${isStudent
        ? `<tr><td style="padding:10px 14px;background:#162032;color:#94a3b8;">📚 Branch</td><td style="padding:10px 14px;background:#162032;color:white;">${user.branch}</td></tr>
           <tr><td style="padding:10px 14px;background:#1e293b;border-radius:0 0 8px 8px;color:#94a3b8;">📅 Semester</td><td style="padding:10px 14px;background:#1e293b;border-radius:0 0 8px 8px;color:white;">Semester ${user.semester}</td></tr>`
        : `<tr><td style="padding:10px 14px;background:#162032;border-radius:0 0 8px 8px;color:#94a3b8;">🏫 Dept</td><td style="padding:10px 14px;background:#162032;border-radius:0 0 8px 8px;color:white;">${user.department}</td></tr>`}
    </table>
    <div style="margin:20px 0;padding:14px 18px;background:#162032;border-left:3px solid #6366f1;border-radius:0 8px 8px 0;">
      <p style="margin:0;font-size:13px;color:#94a3b8;">🕐 Login Time</p>
      <p style="margin:4px 0 0;color:white;font-weight:bold;">${now} IST</p>
    </div>
    <p style="color:#64748b;font-size:12px;">If this wasn't you, contact your administrator immediately.</p>
  </div>
  <div style="padding:16px 32px;background:#0a0f1e;text-align:center;">
    <p style="margin:0;color:#475569;font-size:11px;">EduPredict — RYMEC College · Automated Security Alert</p>
  </div>
</div>`;
  try {
    await transporter.sendMail({ from:`"EduPredict 🎓" <${SENDER_EMAIL}>`, to:user.email, subject:`🔐 EduPredict Login Alert — ${user.name}`, html });
    console.log(`📧 Login email sent → ${user.email}`);
  } catch(e) {
    console.error(`❌ Email failed for ${user.email}:`, e.message);
  }
}

/* ════════════════════════════════════════════════
   CSV DATASET
═══════════════════════════════════════════════════*/
const CSV_PATH = path.join(__dirname, 'data', 'StudentPerformanceFactors.csv');
let DATASET = [];
function parseCSV(raw) {
  const lines = raw.replace(/\r/g,'').trim().split('\n');
  const headers = lines[0].split(',');
  return lines.slice(1).map(line => {
    const vals = line.split(','); const obj = {};
    headers.forEach((h,i) => { const v=vals[i]??''; obj[h.trim()]=isNaN(v)||v===''?v.trim():Number(v); });
    return obj;
  });
}
try { DATASET = parseCSV(fs.readFileSync(CSV_PATH,'utf8')); console.log(`✅ CSV: ${DATASET.length} records`); }
catch(e) { console.warn('⚠️  CSV not found'); }

function avg(arr,key){ const v=arr.map(r=>r[key]).filter(v=>typeof v==='number'); return v.length?+(v.reduce((a,b)=>a+b,0)/v.length).toFixed(2):0; }
function countBy(arr,key){ const c={}; arr.forEach(r=>{const v=r[key];c[v]=(c[v]||0)+1;}); return c; }
function histogram(arr,key,b=10){ const v=arr.map(r=>r[key]).filter(v=>typeof v==='number'); const mn=Math.min(...v),mx=Math.max(...v),sz=(mx-mn)/b; return Array.from({length:b},(_,i)=>({label:`${Math.round(mn+i*sz)}-${Math.round(mn+(i+1)*sz)}`,count:0,range:[mn+i*sz,mn+(i+1)*sz]})).map((bin,i)=>{v.forEach(x=>{if(Math.min(Math.floor((x-mn)/sz),b-1)===i)bin.count++;});return bin;}); }
function pearson(x,y){ const n=x.length,mx=x.reduce((a,b)=>a+b,0)/n,my=y.reduce((a,b)=>a+b,0)/n,num=x.reduce((s,xi,i)=>s+(xi-mx)*(y[i]-my),0),den=Math.sqrt(x.reduce((s,xi)=>s+(xi-mx)**2,0)*y.reduce((s,yi)=>s+(yi-my)**2,0)); return den?+(num/den).toFixed(3):0; }
function computeCorrelations(data){ const cols=['Hours_Studied','Attendance','Sleep_Hours','Previous_Scores','Tutoring_Sessions','Physical_Activity'],scores=data.map(r=>r.Exam_Score),res={}; cols.forEach(c=>{res[c]=pearson(data.map(r=>r[c]),scores);}); return res; }

/* ════════════════════════════════════════════════
   AUTH
═══════════════════════════════════════════════════*/
app.post('/api/login', async (req,res) => {
  const { email, password } = req.body;
  db.read();
  const user = db.data.users.find(u => u.email.toLowerCase()===email.toLowerCase().trim() && u.password===password);
  if (!user) return res.status(401).json({ error:'Invalid email or password' });
  db.data.login_logs.push({ userId:user.id, email:user.email, name:user.name, role:user.role, timestamp:new Date().toISOString(), ip:req.ip||'unknown' });
  db.write();
  sendLoginEmail(user).catch(()=>{});
  const { password:_, ...safe } = user;
  res.json({ success:true, user:safe });
});

app.get('/api/students', (req,res) => {
  db.read();
  res.json(db.data.users.filter(u=>u.role==='student').map(({password,...u})=>u));
});
app.get('/api/users', (req,res) => {
  db.read();
  res.json(db.data.users.map(({password,...u})=>u));
});
app.get('/api/login-logs', (req,res) => {
  db.read();
  res.json(db.data.login_logs.slice().reverse());
});

/* ════════════════════════════════════════════════
   USER MANAGEMENT
═══════════════════════════════════════════════════*/
app.post('/api/users', (req,res) => {
  db.read();
  if (db.data.users.find(u=>u.email===req.body.email)) return res.status(400).json({error:'Email exists'});
  const role=req.body.role||'student', prefix=role==='teacher'?'T':'S';
  const count=db.data.users.filter(u=>u.role===role).length+1;
  const newUser={id:`${prefix}${String(count).padStart(3,'0')}`, ...req.body};
  db.data.users.push(newUser); db.write();
  const {password,...safe}=newUser; res.json({success:true,user:safe});
});
app.put('/api/users/:id', (req,res) => {
  db.read();
  const idx=db.data.users.findIndex(u=>u.id===req.params.id);
  if (idx===-1) return res.status(404).json({error:'Not found'});
  db.data.users[idx]={...db.data.users[idx],...req.body}; db.write();
  const {password,...safe}=db.data.users[idx]; res.json({success:true,user:safe});
});
app.delete('/api/users/:id', (req,res) => {
  db.read();
  const idx=db.data.users.findIndex(u=>u.id===req.params.id);
  if (idx===-1) return res.status(404).json({error:'Not found'});
  db.data.users.splice(idx,1); db.write(); res.json({success:true});
});

/* ════════════════════════════════════════════════
   ANALYTICS
═══════════════════════════════════════════════════*/
app.get('/api/dataset',(req,res)=>{ const p=parseInt(req.query.page||'1'),l=parseInt(req.query.limit||'50'),s=(p-1)*l; res.json({total:DATASET.length,page:p,limit:l,pages:Math.ceil(DATASET.length/l),data:DATASET.slice(s,s+l)}); });
app.get('/api/analytics/summary',(req,res)=>{ const d=DATASET; if(!d.length) return res.json({error:'No data'}); res.json({total_students:d.length,avg_exam_score:avg(d,'Exam_Score'),avg_hours_studied:avg(d,'Hours_Studied'),avg_attendance:avg(d,'Attendance'),avg_sleep_hours:avg(d,'Sleep_Hours'),avg_previous_scores:avg(d,'Previous_Scores'),avg_tutoring_sessions:avg(d,'Tutoring_Sessions'),avg_physical_activity:avg(d,'Physical_Activity'),score_histogram:histogram(d,'Exam_Score',10),hours_histogram:histogram(d,'Hours_Studied',8),gender_dist:countBy(d,'Gender'),school_type_dist:countBy(d,'School_Type'),parental_involvement:countBy(d,'Parental_Involvement'),access_to_resources:countBy(d,'Access_to_Resources'),motivation_level:countBy(d,'Motivation_Level'),family_income:countBy(d,'Family_Income'),teacher_quality:countBy(d,'Teacher_Quality'),peer_influence:countBy(d,'Peer_Influence'),learning_disabilities:countBy(d,'Learning_Disabilities'),internet_access:countBy(d,'Internet_Access'),extracurricular:countBy(d,'Extracurricular_Activities'),parental_education:countBy(d,'Parental_Education_Level'),distance_from_home:countBy(d,'Distance_from_Home'),score_bands:{'Excellent (80-100)':d.filter(r=>r.Exam_Score>=80).length,'Good (65-79)':d.filter(r=>r.Exam_Score>=65&&r.Exam_Score<80).length,'Average (50-64)':d.filter(r=>r.Exam_Score>=50&&r.Exam_Score<65).length,'At Risk (<50)':d.filter(r=>r.Exam_Score<50).length},correlations:computeCorrelations(d)}); });
app.get('/api/analytics/factors',(req,res)=>{ const d=DATASET,fa=(key,groups)=>groups.map(g=>({group:g,avg_score:avg(d.filter(r=>r[key]===g),'Exam_Score'),count:d.filter(r=>r[key]===g).length})); res.json({by_motivation:fa('Motivation_Level',['Low','Medium','High']),by_parental:fa('Parental_Involvement',['Low','Medium','High']),by_resources:fa('Access_to_Resources',['Low','Medium','High']),by_teacher:fa('Teacher_Quality',['Low','Medium','High']),by_peer:fa('Peer_Influence',['Negative','Neutral','Positive']),by_income:fa('Family_Income',['Low','Medium','High']),by_school:fa('School_Type',['Public','Private']),by_internet:fa('Internet_Access',['Yes','No']),by_extracurr:fa('Extracurricular_Activities',['Yes','No']),by_disabilities:fa('Learning_Disabilities',['Yes','No']),by_gender:fa('Gender',['Male','Female']),by_distance:fa('Distance_from_Home',['Near','Moderate','Far'])}); });

/* ════════════════════════════════════════════════
   PREDICT
═══════════════════════════════════════════════════*/
app.post('/api/predict',(req,res)=>{ const {hours_studied=6,attendance=75,sleep_hours=7,previous_scores=70,tutoring_sessions=1,physical_activity=3,motivation_level='Medium',parental_involvement='Medium',access_to_resources='Medium',internet_access='Yes',extracurricular='No',cgpa,studyHours}=req.body; const hrs=studyHours??hours_studied,att=cgpa?cgpa*10:attendance,prev=previous_scores; const mB={Low:-4,Medium:0,High:5}[motivation_level]??0,pB={Low:-2,Medium:0,High:3}[parental_involvement]??0,rB={Low:-3,Medium:0,High:4}[access_to_resources]??0,iB=internet_access==='Yes'?2:-1,eB=extracurricular==='Yes'?1:0; const rawScore=(hrs/44)*15+(att/100)*20+(sleep_hours/10)*8+(prev/100)*35+(tutoring_sessions/8)*10+(physical_activity/6)*5+mB+pB+rB+iB+eB; const score=Math.min(100,Math.max(30,Math.round(rawScore))); let grade,label,color; if(score>=80){grade='A+';label='Excellent';color='#10b981';}else if(score>=65){grade='A';label='Good';color='#38bdf8';}else if(score>=50){grade='B';label='Average';color='#fbbf24';}else if(score>=40){grade='C';label='Below Average';color='#fb923c';}else{grade='D';label='At Risk';color='#f43f5e';} const similar=DATASET.filter(r=>Math.abs(r.Hours_Studied-hrs)<5&&Math.abs(r.Attendance-att)<10&&Math.abs(r.Previous_Scores-prev)<15).slice(0,5),avgSimilar=similar.length?avg(similar,'Exam_Score'):null; const tips=[]; if(hrs<6)tips.push({factor:'Study Hours',tip:`Studying ${hrs}h/day — aim for 8+.`}); if(att<80)tips.push({factor:'Attendance',tip:`${att}% attendance — try to exceed 85%.`}); if(sleep_hours<7)tips.push({factor:'Sleep',tip:'Aim for 7-8 hours of sleep.'}); if(tutoring_sessions<2)tips.push({factor:'Tutoring',tip:'2+ sessions/week improve scores by ~4 points.'}); if(motivation_level==='Low')tips.push({factor:'Motivation',tip:'Low motivation students score 8 pts below high motivation peers.'}); if(!tips.length)tips.push({factor:'Keep it up!',tip:'Strong inputs — maintain consistency.'}); res.json({grade,label,score,color,avgSimilar,similarCount:similar.length,tips,dataset_size:DATASET.length}); });

/* ════════════════════════════════════════════════
   POINTS
═══════════════════════════════════════════════════*/
app.post('/api/points/award',(req,res)=>{ db.read(); const {studentId,points}=req.body; if(!db.data.points_db[studentId])db.data.points_db[studentId]=0; db.data.points_db[studentId]+=points; db.write(); res.json({success:true,total:db.data.points_db[studentId]}); });
app.get('/api/points/:studentId',(req,res)=>{ db.read(); res.json({points:db.data.points_db[req.params.studentId]||0}); });

/* COURSES */
const COURSES=[{id:1,title:'Data Structures & Algorithms',branch:'CSE',difficulty:'Intermediate',duration:'40 hours',youtubeUrl:'https://www.youtube.com/watch?v=8hly31xKli0'},{id:2,title:'Machine Learning A-Z',branch:'CSE',difficulty:'Advanced',duration:'50 hours',youtubeUrl:'https://www.youtube.com/watch?v=jGwO_UgTS7I'},{id:3,title:'Full Stack Web Development',branch:'IT',difficulty:'Beginner',duration:'60 hours',youtubeUrl:'https://www.youtube.com/watch?v=nu_pCVPKzTk'},{id:4,title:'Python for Beginners',branch:'CSE',difficulty:'Beginner',duration:'25 hours',youtubeUrl:'https://www.youtube.com/watch?v=_uQrJ0TkZlc'},{id:5,title:'Deep Learning with PyTorch',branch:'CSE',difficulty:'Advanced',duration:'45 hours',youtubeUrl:'https://www.youtube.com/watch?v=VMj-3S1tku0'},{id:6,title:'AWS Cloud Practitioner',branch:'IT',difficulty:'Beginner',duration:'30 hours',youtubeUrl:'https://www.youtube.com/watch?v=SOTamWNgDKc'}];
app.get('/api/courses',(req,res)=>res.json(COURSES));

/* EMAIL CONFIG */
app.post('/api/email/configure',(req,res)=>{ const {senderEmail,senderPass}=req.body; if(!senderEmail||!senderPass) return res.status(400).json({error:'Both fields required'}); transporter=nodemailer.createTransport({service:'gmail',auth:{user:senderEmail,pass:senderPass}}); res.json({success:true,message:`Email configured for ${senderEmail}`}); });
app.get('/api/email/status',(req,res)=>res.json({configured:transporter!==null&&SENDER_EMAIL!=='YOUR_GMAIL@gmail.com',sender:SENDER_EMAIL==='YOUR_GMAIL@gmail.com'?'Not configured':SENDER_EMAIL}));

/* HEALTH */
app.get('/api/health',(req,res)=>{ db.read(); res.json({status:'ok',database:'JSON/lowdb',users:db.data.users.length,students:db.data.users.filter(u=>u.role==='student').length,teachers:db.data.users.filter(u=>u.role==='teacher').length,login_logs:db.data.login_logs.length,dataset_loaded:DATASET.length,email_configured:transporter!==null&&SENDER_EMAIL!=='YOUR_GMAIL@gmail.com',version:'3.1'}); });

/* ════════════════════════════════════════════════
   AI EVALUATOR — Log & History
═══════════════════════════════════════════════════*/
if (!db.data.eval_logs) { db.data.eval_logs = []; db.write(); }

app.post('/api/eval/log', (req, res) => {
  db.read();
  const { userId, mode, subject, score, maxScore, grade } = req.body;
  const entry = { id: Date.now().toString(), userId, mode, subject, score, maxScore, grade, timestamp: new Date().toISOString() };
  if (!db.data.eval_logs) db.data.eval_logs = [];
  db.data.eval_logs.push(entry);
  db.write();
  res.json({ success: true, entry });
});

app.get('/api/eval/logs/:userId', (req, res) => {
  db.read();
  const logs = (db.data.eval_logs || []).filter(l => l.userId === req.params.userId);
  res.json(logs);
});

app.get('/api/eval/stats', (req, res) => {
  db.read();
  const logs = db.data.eval_logs || [];
  const byMode = {};
  logs.forEach(l => { byMode[l.mode] = (byMode[l.mode] || 0) + 1; });
  res.json({ total: logs.length, by_mode: byMode });
});


app.listen(PORT,()=>{ console.log(`\n🚀 EduPredict v3.0 on port ${PORT}`); console.log(`📦 DB: ${DB_PATH}`); console.log(`📧 Email: ${SENDER_EMAIL==='YOUR_GMAIL@gmail.com'?'⚠️  Not configured':SENDER_EMAIL}\n`); });

/* ════════════ AI PROXY ════════════ */
app.post('/api/ai/chat', async (req, res) => {
  const KEY = process.env.ANTHROPIC_API_KEY;
  if (!KEY || KEY === 'YOUR_ANTHROPIC_API_KEY_HERE') {
    return res.status(400).json({
      _nokey: true,
      error: 'API key not set',
      hint: 'Add ANTHROPIC_API_KEY=sk-ant-... to backend/.env then restart server'
    });
  }
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'x-api-key': KEY,
        'anthropic-version':'2023-06-01',
        'anthropic-beta':'pdfs-2024-09-25',
      },
      body: JSON.stringify(req.body),
    });
    const data = await r.json();
    res.status(r.status).json(data);
  } catch(e) {
    res.status(500).json({ error: 'Proxy error', detail: e.message });
  }
});
